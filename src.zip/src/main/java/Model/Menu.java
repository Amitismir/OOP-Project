package Model;
//import com.example.myapp.controller.Controller;

public interface Menu {
    void display();
    Menu handleInput(String input);
}
