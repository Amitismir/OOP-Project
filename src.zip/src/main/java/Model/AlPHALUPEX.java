package Model;

public class AlPHALUPEX implements character {

    String name = "ALPHA LUPEX";
    public int increment = 2;
    @Override
    public String getName() {
        return name;
    }

    public int getIncrement() {
        return increment;
    }
}
