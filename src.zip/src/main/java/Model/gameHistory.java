package Model;

import Controller.Controller;

import java.sql.*;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class gameHistory implements Menu {
    final String DB_URL = "jdbc:mysql://127.0.0.1:3306/oop_proj";
    final String USERNAME = "root";
    final String PASSWORD = "138387Amitis";
    int currentPage = 1;
    int rowLimit;
    String table_name = Controller.currentuser.username.toLowerCase() + "_gamehistory";
    public int pageLimit = assignPageLimit(table_name);
    Scanner sc = new Scanner(System.in);
    public void display() {

        System.out.println("Welcome to game history menu!");
        System.out.println("PAGE 1: ");
        //show the first page of the table
        System.out.println("+-----+-------+-----------------+------------------+----------+----------------------------------------+");
        System.out.println("| no. | state |     outcome     |     opponent     | oppLevel |                  time                  |");
        System.out.println("+-----+-------+-----------------+------------------+----------+----------------------------------------+");
        int idThreshold = 0;
        if(rowLimit<10)
            idThreshold = rowLimit;
        else
            idThreshold = 10;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = conn.createStatement();
            ResultSet resultSet;
            for(int i = 1; i<=idThreshold; i++){
                resultSet = statement.executeQuery("select * from " + table_name + " where id = " + i);
                while (resultSet.next()) {
                    System.out.println(String.format("| %-3s | %-5s | %-15s | %-16s | %-8s | %-38s |", resultSet.getInt("id"),
                            resultSet.getString("state"), resultSet.getString("outcome"),
                            resultSet.getString("opponent"), resultSet.getString("oppLevel"), resultSet.getString("time")));
                    System.out.println("+-----+-------+-----------------+------------------+----------+----------------------------------------+");
                }
            }

        }catch(SQLException E){
            E.printStackTrace();
        }
        System.out.println();
        System.out.println();

        System.out.println("You can either choose one of the syntax below or enter 'exit' to go back to the main menu:");
        System.out.println("1. next page");
        System.out.println("2. previous page");
        System.out.println("3. show page <pageNumber>");
        System.out.println("4. have a challenge with <username>");
    }
    public Menu handleInput(String input) {
        if(rowLimit == 0){
            System.out.println("ERROR: YOUR GAME HISTORY TABLE IS EMPTY");
            System.out.println("You will be returned to the main menu now. Play a game to add to your history.");
            return new MainMenu();
        }
        while(!input.toLowerCase().matches("exit")){
            if(input.toLowerCase().matches("1") || input.toLowerCase().matches("next page")){
                if(currentPage + 1 > pageLimit){
                    System.out.println("There are no more pages left...");
                    System.out.println("Try again:");
                    input = sc.nextLine();
                    continue;
                }
                currentPage++;
                printTable(currentPage);
                input = sc.nextLine();
            }
            else if(input.toLowerCase().matches("2") || input.toLowerCase().matches("previous page")){
                if(currentPage-1 < 1){
                    System.out.println("There is no previous page...");
                    System.out.println("Try again:");
                    input = sc.nextLine();
                    continue;
                }
                currentPage--;
                printTable(currentPage);
                input = sc.nextLine();
            }
            else if( input.toLowerCase().matches("show page (?<number>\\d+)")){
                Matcher Mt = getCommandMatcher(input, "show page (?<number>\\d+)");
                Mt.find();
                //handle existence
                int entered = Integer.parseInt(Mt.group("number"));
                if(entered<1 || entered>pageLimit){
                    System.out.println("This page does not exist...");
                    System.out.println("Try again:");
                    input = sc.nextLine();
                    continue;
                }
                currentPage = entered;
                printTable(currentPage);
                input =  sc.nextLine();
            }
            else if(input.toLowerCase().matches("3")){
                System.out.println("Enter a page number");
                int entered = sc.nextInt();
                if(entered<1 || entered>pageLimit){
                    System.out.println("This page does not exist...");
                    System.out.println("Try again:");
                    input = sc.nextLine();
                    continue;
                }
                currentPage = entered;
                printTable(currentPage);
                input =  sc.nextLine();
            }
            else if(input.toLowerCase().matches("have a challenge with (?<username>.+)")){
                Matcher Mt = getCommandMatcher(input, "have a challenge with (?<username>.+)");
                Mt.find();
                try{
                    Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    Statement statement = conn.createStatement();
                    ResultSet resultSet = statement.executeQuery("select * from " + table_name + " where opponent = \"" + Mt.group("username") + "\";");
                    if(!resultSet.next()){
                        System.out.println("There is no such username among your previous opponents.");
                        continue;
                    }
                    String tableName = Mt.group("username") + "_challengerequest";
                    Statement statement1 = conn.createStatement();
                    String query = "insert into " + tableName + "(username) values (\"" + Controller.currentuser.getUsername() + "\");";
                    int rowsAffected = statement1.executeUpdate(query);
                    System.out.println("Request saved in DB successfully.");
                    System.out.println(rowsAffected + " row(s) affected.");
                    System.out.println("Whenever the user logs in, they will see your challenge request.");

                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                }
                input = sc.nextLine();
            }
            else if(input.toLowerCase().matches("4")){
                System.out.println("Enter a username:");
                String username = sc.nextLine();
                try{
                    Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    Statement statement = conn.createStatement();
                    ResultSet resultSet = statement.executeQuery("select * from " + table_name + " where opponent = \"" + username + "\";");
                    if(!resultSet.next()){
                        System.out.println("There is no such username among your previous opponents.");
                        continue;
                    }
                    String tableName = username + "_challengerequest";
                    Statement statement1 = conn.createStatement();
                    String query = "insert into " + tableName + "(username) values (\"" + Controller.currentuser.getUsername() + "\");";
                    int rowsAffected = statement1.executeUpdate(query);
                    System.out.println("Request saved in DB successfully.");
                    System.out.println(rowsAffected + " row(s) affected.");
                    System.out.println("Whenever the user logs in, they will see your challenge request.");

                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                }
                input = sc.nextLine();
            }
            else{
                System.out.println("INVALID INPUT. TRY AGAIN:");
                input = sc.nextLine();
            }
        }
        return new MainMenu();
    }
    public int assignPageLimit(String tablename){
        int rowCount = 0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            //System.out.println(table_name);
            String query = "select count(*) as total_rows from " + tablename + ";";
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()){
                rowCount = resultSet.getInt("total_rows");
            }
            rowLimit = rowCount;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return (int) Math.ceil((double) rowCount / 10);
    }
    public void printTable(int page){
        //do not say 50 to 60 handle limit
        int idThresh;
        if(page*10 > rowLimit)
            idThresh = rowLimit;
        else
            idThresh = page*10;
        System.out.println("PAGE " + page + ":");
        System.out.println("+-----+-------+-----------------+------------------+----------+----------------------------------------+");
        System.out.println("| no. | state |     outcome     |     opponent     | oppLevel |                  time                  |");
        System.out.println("+-----+-------+-----------------+------------------+----------+----------------------------------------+");
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = conn.createStatement();
            ResultSet resultSet;
            for(int i = ((page-1)*10)+1; i<=idThresh; i++){
                resultSet = statement.executeQuery("select * from " + table_name + " where id = " + i);
                while (resultSet.next()) {
                    System.out.println(String.format("| %-3s | %-5s | %-15s | %-16s | %-8s | %-38s |", resultSet.getInt("id"),
                            resultSet.getString("state"), resultSet.getString("outcome"),
                            resultSet.getString("opponent"), resultSet.getString("oppLevel"), resultSet.getString("time")));
                    System.out.println("+-----+-------+-----------------+------------------+----------+----------------------------------------+");
                }
            }

        }catch(SQLException E){
            E.printStackTrace();
        }
    }
    private Matcher getCommandMatcher(String input, String regex){
        return Pattern.compile(regex).matcher(input);
    }
}
