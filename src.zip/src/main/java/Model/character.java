package Model;

public interface character {
    String name = "";
     public final int increment = 0;

    public String getName();
    public int getIncrement();


}
